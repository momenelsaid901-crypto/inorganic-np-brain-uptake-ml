BBB v6 RIGOROUS NESTED GROUPED VALIDATION
=========================================

DATA AND ENDPOINT
-----------------
Rows: 140
Independent Study_Group values: 33
Formulations: 59
Materials: Gold, Iron Oxide, Silica
Endpoint: quantitative whole-brain biodistribution (%ID/g), not demonstrated
BBB crossing or parenchymal localization.

PRIMARY VALIDATION ESTIMAND
---------------------------
Performance of the complete selection procedure on unseen Study_Group values.
Within every outer training partition, inner grouped CV selects the feature set,
model family, target transform, and hyperparameters. The outer test groups do not
participate in any selection decision.

PRIMARY NESTED-SELECTION RESULTS
--------------------------------
Study-macro MAE: 0.258994 %ID/g
95% group-bootstrap CI: [0.187921, 0.350551]
Observation-weighted MAE: 0.294682 %ID/g
Observation-weighted RMSE: 0.463233 %ID/g
95% group-bootstrap CI: [0.280537, 0.652578]
Pooled outer OOF R2: -0.001464
95% group-bootstrap CI: [-0.185856, 0.051820]
Group-mean Spearman rho: 0.118003
Group-level permutation p-value: 0.502675

Dummy study-aware baseline study-macro MAE: 0.258669 %ID/g

R2 INTERPRETATION
-----------------
The pooled outer out-of-fold R2 is non-positive. The complete model-selection procedure does not outperform prediction by the training mean in explained-variance terms for unseen studies.

Q2
---
Q2 is intentionally omitted. Under the definition used in earlier scripts, Q2
was exactly the pooled out-of-fold R2 and was not an independent metric.

UNCERTAINTY AND MODEL COMPARISONS
---------------------------------
All main metrics have 95% cluster-bootstrap intervals using Study_Group as the
resampling unit. Family procedures were evaluated on identical outer splits.
Paired differences in study-level MAE are accompanied by bootstrap intervals,
paired sign-flip permutation p-values, and Holm multiplicity correction. These
comparisons assess both statistical uncertainty and effect magnitude.
Minimum Holm-adjusted p-value across the primary pairwise comparisons:
1.000000. No algorithmic advantage should be claimed when
the adjusted comparison is not significant and its effect interval includes zero.

GROUP-AWARE CORRELATION
-----------------------
The inferential Spearman analysis uses one observed mean and one predicted mean
per Study_Group and a permutation test across study units. Observation-level
Spearman correlation is retained only as a descriptive statistic and has no
naive row-level p-value.

ZERO TARGETS
------------
Seven values from URL:http://ijrr.com/article-1-3074-en.pdf are explicitly reported in Table 1 of DOI
10.18869/acadpub.ijrr.18.3.539 as brain uptake 0.0 +/- 0.0 %ID/g. The publication does not
provide an organ-specific detection or quantification limit. They are therefore
retained as reported rounded zeros without claiming proven absence of uptake.
A sensitivity analysis excludes that entire study group.
Sensitivity nested-selection study-macro MAE:
0.309903 %ID/g.
Sensitivity pooled outer OOF R2: -0.046134.

MATERIAL AND STUDY_GROUP
------------------------
Proportion of studies containing exactly one material: 1.000.
Thus Study_Group perfectly determines Material within this dataset. Material is
a scientifically meaningful descriptor but also a study-level characteristic,
so its importance must not be interpreted as independent causal evidence. A
prespecified feature set excluding Material is included in inner selection.

FEATURE-SET INTERPRETATION
--------------------------
A: basic nanoparticle descriptors.
B: enriched nanoparticle descriptors.
C: nanoparticle descriptors PLUS experimental, biological, and measurement
   context. B-to-C differences are not solely effects of nanoparticle properties.
D: the full-context sensitivity set without Material.

INTERPRETABILITY
----------------
SHAP from an all-data fitted model is omitted. Reported permutation importance is
computed only on outer held-out studies. Stability is summarized across outer
folds; features absent from a fold's selected feature set receive no importance
claim for that fold.

FINAL FUTURE-USE MODEL
----------------------
After unbiased assessment was complete, inner grouped CV on all available data
selected:
Candidate(family='ExtraTrees', feature_set='B_enriched_nanoparticle', target_transform='log1p', parameters_json='{"max_depth": 3, "max_features": "sqrt", "min_samples_leaf": 2}')
This final all-data fit is stored only for future prediction. Its training fit is
not used as evidence of predictive performance.

OUTER-FOLD SELECTION FREQUENCIES
--------------------------------
family      feature_set                               target_transform
ExtraTrees  D_full_context_without_material           log1p               2
ElasticNet  A_basic_nanoparticle                      log1p               1
ExtraTrees  C_nanoparticle_plus_experimental_context  raw                 1
Ridge       A_basic_nanoparticle                      raw                 1

SOFTWARE
--------
Exact Python and package versions are recorded in environment_versions.json.
No global warnings are suppressed.
